# JoinMessageOTD
A PocketMine Plugin that will display a Message to the player who joined

*This is not finished yet*
