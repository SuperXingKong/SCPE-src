## Gitter.IM chat
[![Gitter](https://badges.gitter.im/thelucyclub/Pets.svg)](https://gitter.im/thelucyclub/Pets?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)
# Pets
#### First Release To Do:
- [x] Add Primary Command
- [x] Enable full use of config.yml
- [x] Add help SubCommand
- [x] Add pet spawn SubCommand
- [ ] Add pet teleporting SubCommand
- [ ] Add pet renaming SubCommand

#### Beta Features:
- [ ] Implement Dogs as pets not wolves
- [ ] Make pet follow owner (Add pet AI)
- [ ] Have pet take the loot when owner kills another player (more pet AI)
- [ ] Add pet inventory SubCommand
- [ ] Restrict pet inventory access to owner
- [ ] Drops pet's inventory in a chest if the pet dies
- [ ] Implement Cats as pets not ocelots
- [ ] Allow players to give away pets with inventories
