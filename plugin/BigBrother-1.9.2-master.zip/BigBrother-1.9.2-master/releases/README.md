# how to play without crashing

- Use ClearSky Protocol 45 (PHP5)
