# BigBrother-0.14.0
the pocketmine plugin big brother for 0.14.0 

##Support Version

- master = PHP7

- Minecraft PC 1.9

- Minecraft PE 0.14.0

- PHP5 tree 

##To-Do
- Optimized server
- Place Blocks
- PC Receive Message
- 
##Info
http://wiki.vg/Pocket_Minecraft_Protocol#Login_Packets
http://wiki.vg/Protocol
