<?php
namespace ImagicalGamer\Stats;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};

use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;

use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\level\particle\Particle;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\level\Position\getLevel;
use pocketmine\math\Vector3;

use pocketmine\utils\TextFormat as C;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener{
  public function onEnable(){
          $this->getServer()->getPluginManager()->registerEvents($this, $this);
          $this->getLogger()->info(C::GREEN . "Enabled!");
  	  $this->saveResource("kills.yml");
          $this->saveResource("deaths.yml");
          $this->saveResource("places.yml");
	  $this->saveResource("breaks.yml");
          @mkdir($this->getDataFolder());
	  $killfile = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
  	  $killfile->save();
  	  $deathfile = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
  	  $deathfile->save();
  	  $placefile = new Config($this->getDataFolder() . "/places.yml", Config::YAML);
  	  $placefile->save();
  	  $breakfile = new Config($this->getDataFolder() . "/breaks.yml", Config::YAML);
  	  $breakfile->save();
  }
  public function onDeath(PlayerDeathEvent $event){
  	$deathdata = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
  	$killdata = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
  	$entity = $event->getEntity();
  	$cause = $entity->getLastDamageCause();
        $killer = $cause->getDamager();
  	if($entity instanceof Player){
        $name = $event->getEntity()->getName();
  	    $deaths = $deathdata->get($name);
  	    $deathdata->set($name,$deaths+1);
  	    $deathdata->save();
  	}
  	if($killer instanceof Player){
  	  $name = $killer->getName();
  	  $kills = $killdata->get($name);
  	  $killdata->set($name,$kills+1);
  	  $killdata->save();
  	}
  }
  public function onBreak(BlockBreakEvent $event){
    $name = $event->getPlayer()->getName();
    $breakdata = new Config($this->getDataFolder() . "/breaks.yml", Config::YAML);
    $breaks = $breakdata->get($name);
  	$breakdata->set($name,$breaks+1);
  	$breakdata->save();
  }
  public function onPlace(BlockPlaceEvent $event){
    $name = $event->getPlayer()->getName();
    $placedata = new Config($this->getDataFolder() . "/places.yml", Config::YAML);
    $places = $placedata->get($name);
  	$placedata->set($name,$places+1);
  	$placedata->save();
  }
  public function onCommand(CommandSender $s, Command $cmd, $label, array $args){
        if($cmd->getName() == "stats"){
          if($s instanceof Player){
          if(count($args) == 0) {
            $killfile = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
            $kills = $killfile->get($s->getName());
            $deathfile = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
            $deaths = $deathfile->get($s->getName());
            $placefile = new Config($this->getDataFolder() . "/places.yml", Config::YAML);
            $places = $placefile->get($s->getName());
            $breakfile = new Config($this->getDataFolder() . "/breaks.yml", Config::YAML);
            $breaks = $breakfile->get($s->getName());
            $stats = C::GREEN . C::BOLD . "Your Stats!" . C::RESET . C::GREEN . "\nKills: " . $kills . "\nDeaths: " . $deaths . "\nBreaks: " . $breaks . "\nPlaces: " . $places;
            $s->sendMessage($stats);
          }
          if(count($args) == 1){
            $player = $args[0];
            $killfile = new Config($this->getDataFolder() . "/kills.yml", Config::YAML);
            $kills = $killfile->get($player);
            $deathfile = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
            $deaths = $deathfile->get($player);
            $placefile = new Config($this->getDataFolder() . "/places.yml", Config::YAML);
            $places = $placefile->get($player);
            $breakfile = new Config($this->getDataFolder() . "/breaks.yml", Config::YAML);
            $breaks = $breakfile->get($player);
            $stats = C::GREEN . C::BOLD . $args[0] . "'s' Stats!" . C::RESET . C::GREEN . "\nKills: " . $kills . "\nDeaths: " . $deaths . "\nBreaks: " . $breaks . "\nPlaces: " . $places;
            $s->sendMessage($stats);
          }
        }
      }
}
  public function onJoin(PlayerJoinEvent $event){
    $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
	$enabled= $config->get("Floating-Stats");
    $player = $event->getPlayer();
    $name = $player->getName();
    $killfile = new Config($this->getDataFolder() . "kills.yml", Config::YAML);
    $kills = $killfile->get($name);
    $deathfile = new Config($this->getDataFolder() . "/deaths.yml", Config::YAML);
    $deaths = $deathfile->get($name);
    $placefile = new Config($this->getDataFolder() . "/places.yml", Config::YAML);
    $places = $placefile->get($name);
    $breakfile = new Config($this->getDataFolder() . "/breaks.yml", Config::YAML);
    $breaks = $breakfile->get($name);
    $text = C::AQUA . C::BOLD . "-= Your Stats =-" . C::RESET . C::AQUA . "\nPlaces: " . C::BOLD . C::GRAY . $places . C::RESET . C::AQUA . "\nBreaks: " . C::GRAY . C::BOLD . $breaks . C::RESET . C::AQUA . "\nKills: " . C::GRAY . C::BOLD . $kills . C::RESET . C::AQUA . "\nDeaths: " . C::GRAY . C::BOLD . $deaths; 
    $x = $player->getX();
    $y = $player->getY();
    $z = $player->getZ();
    $level = $player->getLevel();
    $particle = new FloatingTextParticle(new Vector3($x, $y+2, $z), $text);
    $level->addParticle($particle);
}
}
