<?php

namespace onebone\artificialintelligent\entity;

interface MovingEntity{}
