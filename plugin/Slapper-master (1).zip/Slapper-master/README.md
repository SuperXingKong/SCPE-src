# Slapper
Slapper - An NPC plugin for PocketMine
