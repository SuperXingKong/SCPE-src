<?php
namespace slapper\entities;

use pocketmine\entity\Human;

class HumanNPC extends Human
{
}
