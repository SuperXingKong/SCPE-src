<?php
namespace slapper\entities;

interface SlapperEntity{
}
